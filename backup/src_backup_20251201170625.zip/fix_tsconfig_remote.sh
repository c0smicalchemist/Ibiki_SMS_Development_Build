sed -i 's/"compilerOptions": { "skipLibCheck": true,/"compilerOptions": { /' /opt/ibiki-sms/tsconfig.json
