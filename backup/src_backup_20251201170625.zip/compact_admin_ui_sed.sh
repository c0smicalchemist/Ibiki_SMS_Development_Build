sed -i 's|<Table>|<Table className="text-sm">|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Client Name</TableHead>|<TableHead className="whitespace-nowrap">Client Name</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Email</TableHead>|<TableHead className="whitespace-nowrap">Email</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>API Key</TableHead>|<TableHead className="whitespace-nowrap">API Key</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Status</TableHead>|<TableHead className="whitespace-nowrap">Status</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Messages Sent</TableHead>|<TableHead className="whitespace-nowrap">Messages</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Credits</TableHead>|<TableHead className="whitespace-nowrap">Credits</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Assigned Numbers</TableHead>|<TableHead className="whitespace-nowrap">Assigned Numbers</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Last Active</TableHead>|<TableHead className="whitespace-nowrap">Last Active</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Delivery Mode</TableHead>|<TableHead className="whitespace-nowrap">Delivery</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Webhook</TableHead>|<TableHead className="whitespace-nowrap">Webhook</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Role</TableHead>|<TableHead className="whitespace-nowrap">Role</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Group ID</TableHead>|<TableHead className="whitespace-nowrap">Group ID</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|<TableHead>Actions</TableHead>|<TableHead className="whitespace-nowrap">Actions</TableHead>|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|className="w-24"|className="w-20 h-8"|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|className="w-36"|className="w-32 h-8"|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|className="w-40 font-mono text-xs"|className="w-40 h-8 font-mono text-[11px]"|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|grid grid-cols-1|grid grid-cols-2 md:grid-cols-1|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|min-w-[10rem]|min-w-[12rem]|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|buttonClassName="w-full justify-start bg-green-600|buttonClassName="w-full h-8 justify-start bg-green-600|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
sed -i 's|buttonClassName="w-full justify-start bg-orange-100|buttonClassName="w-full h-8 justify-start bg-orange-100|g' /opt/ibiki-sms/client/src/pages/AdminDashboard.tsx
