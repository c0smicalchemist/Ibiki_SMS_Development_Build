import ClientDashboard from '../../pages/ClientDashboard';

export default function ClientDashboardExample() {
  return <ClientDashboard />;
}
