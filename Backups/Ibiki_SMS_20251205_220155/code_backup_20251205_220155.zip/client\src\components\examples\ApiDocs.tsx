import ApiDocs from '../../pages/ApiDocs';

export default function ApiDocsExample() {
  return <ApiDocs />;
}
