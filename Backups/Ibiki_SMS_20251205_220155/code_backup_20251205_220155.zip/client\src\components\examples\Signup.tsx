import Signup from '../../pages/Signup';

export default function SignupExample() {
  return <Signup />;
}
