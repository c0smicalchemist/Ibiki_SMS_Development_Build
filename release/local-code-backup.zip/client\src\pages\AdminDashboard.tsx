import { useState, useEffect } from "react";
import { Users, Settings, Activity, ArrowLeft, Wallet, Copy, CheckCircle, Send, Inbox as InboxIcon, Clock, Star } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import StatCard from "@/components/StatCard";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";
import { DashboardHeader } from "@/components/DashboardHeader";
import { Link } from "wouter";
import ApiTestUtility from "@/components/ApiTestUtility";
import ErrorLogsViewer from "@/components/ErrorLogsViewer";
import ActionLogsViewer from "@/components/ActionLogsViewer";
import MessageActivityViewer from "@/components/MessageActivityViewer";
import AdminCreateUser from "@/components/AdminCreateUser";
import SupervisorCreateUser from "@/components/SupervisorCreateUser";
import { AddCreditsToClientDialog } from "@/components/AddCreditsToClientDialog";
import ResetPasswordDialog from "@/components/ResetPasswordDialog";
import WebhookEditDialog from "@/components/WebhookEditDialog";
import { WorldClock } from "@/components/WorldClock";
import { MessageStatusChart } from "@/components/MessageStatusChart";
import MessageStatusTiles from "@/components/MessageStatusTiles";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { t } = useLanguage();
  const [extremeApiKey, setExtremeApiKey] = useState("");
  const [extremeCost, setExtremeCost] = useState("0.01");
  const [clientRate, setClientRate] = useState("0.02");
  const [timezone, setTimezone] = useState("America/New_York");
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'connected' | 'disconnected'>('unknown');
  const [webhookFrom, setWebhookFrom] = useState('');
  const [webhookBusiness, setWebhookBusiness] = useState('');
  const [webhookMessage, setWebhookMessage] = useState('');
  const [webhookMessageId, setWebhookMessageId] = useState('');
  const [flowBusiness, setFlowBusiness] = useState('');
  const [editDeliveryMode, setEditDeliveryMode] = useState<'poll' | 'push' | 'both'>('poll');
  const [editWebhookUrl, setEditWebhookUrl] = useState('');
  const [editWebhookSecret, setEditWebhookSecret] = useState('');
  const [groupIdPricing, setGroupIdPricing] = useState<string>('');
  const [groupExtremeCost, setGroupExtremeCost] = useState<string>('');
  const [groupClientRate, setGroupClientRate] = useState<string>('');

  const usTimezones = [
    { value: "America/New_York", label: "Eastern Time (ET)" },
    { value: "America/Detroit", label: "Eastern Time - Michigan" },
    { value: "America/Kentucky/Louisville", label: "Eastern Time - Louisville, KY" },
    { value: "America/Indiana/Indianapolis", label: "Eastern Time - Indianapolis" },
    { value: "America/Chicago", label: "Central Time (CT)" },
    { value: "America/Indiana/Knox", label: "Central Time - Knox, IN" },
    { value: "America/Menominee", label: "Central Time - Menominee, MI" },
    { value: "America/North_Dakota/Center", label: "Central Time - North Dakota" },
    { value: "America/Denver", label: "Mountain Time (MT)" },
    { value: "America/Boise", label: "Mountain Time - Boise" },
    { value: "America/Phoenix", label: "Mountain Time - Arizona (no DST)" },
    { value: "America/Los_Angeles", label: "Pacific Time (PT)" },
    { value: "America/Anchorage", label: "Alaska Time (AKT)" },
    { value: "America/Juneau", label: "Alaska Time - Juneau" },
    { value: "America/Adak", label: "Hawaii-Aleutian Time (HAT)" },
    { value: "Pacific/Honolulu", label: "Hawaii-Aleutian Time - Honolulu (no DST)" },
  ];

  const { data: config } = useQuery<{ success: boolean; config: Record<string, string> }>({ queryKey: ['/api/admin/config'] });
  const { data: profile } = useQuery<{ user: { id: string; role: string } }>({ queryKey: ['/api/client/profile'] });

  useEffect(() => {
    if (config?.config) {
      setExtremeApiKey(config.config.extreme_api_key || "");
      setExtremeCost(config.config.extreme_cost_per_sms || "0.01");
      setClientRate(config.config.client_rate_per_sms || "0.02");
      setTimezone(config.config.timezone || "America/New_York");
      setWebhookBusiness(config.config.admin_default_business_id || 'IBS_0');
      setSignupSeedExamples((config.config.signup_seed_examples || 'false') === 'true');
    }
  }, [config]);

  const groupPricingQuery = useQuery<{ success: boolean; base: { extremeCost: number; clientRate: number }; group?: { extremeCost?: number; clientRate?: number } | null; groupId: string | null }>({
    queryKey: ['/api/admin/pricing', groupIdPricing || ''],
    queryFn: async () => {
      const url = groupIdPricing ? `/api/admin/pricing?groupId=${encodeURIComponent(groupIdPricing)}` : '/api/admin/pricing';
      const r = await apiRequest(url);
      return r.json();
    },
    enabled: !!groupIdPricing,
  });

  useEffect(() => {
    if (groupPricingQuery.data?.group) {
      const g = groupPricingQuery.data.group;
      setGroupExtremeCost(g.extremeCost !== undefined ? String(g.extremeCost) : '');
      setGroupClientRate(g.clientRate !== undefined ? String(g.clientRate) : '');
    }
  }, [groupPricingQuery.data]);

  const [signupSeedExamples, setSignupSeedExamples] = useState<boolean>(false);

  const saveConfigMutation = useMutation({
    mutationFn: async (data: { extremeApiKey?: string; extremeCost?: string; clientRate?: string; timezone?: string; adminDefaultBusinessId?: string; signupSeedExamples?: boolean }) => {
      return await apiRequest('/api/admin/config', {
        method: 'POST',
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/config'] });
      toast({
        title: "Success",
        description: "Configuration saved successfully"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: t("admin.config.error.saveFailed"),
        variant: "destructive"
      });
    }
  });

  const saveGroupPricingMutation = useMutation({
    mutationFn: async () => {
      const body: any = { groupId: groupIdPricing };
      if (groupExtremeCost) body.extremeCost = parseFloat(groupExtremeCost);
      if (groupClientRate) body.clientRate = parseFloat(groupClientRate);
      return await apiRequest('/api/admin/pricing', { method: 'POST', body: JSON.stringify(body) });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/pricing', groupIdPricing || ''] });
      toast({ title: t('common.success'), description: 'Group pricing saved' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || 'Failed to save group pricing', variant: 'destructive' });
    }
  });

  const testConnectionMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/test-connection', {
        method: 'POST'
      });
    },
    onSuccess: (data: any) => {
      setConnectionStatus('connected');
      toast({
        title: "Connection Successful",
        description: data.message || "ExtremeSMS API is working correctly"
      });
    },
    onError: (error: any) => {
      setConnectionStatus('disconnected');
      toast({
        title: "Connection Failed",
        description: error.message || t("admin.config.error.connectionFailed"),
        variant: "destructive"
      });
    }
  });

  const webhookStatusQuery = useQuery<{ success: boolean; lastEvent: any; lastEventAt: string | null; lastRoutedUser: string | null }>({
    queryKey: ['/api/admin/webhook/status']
  });
  const inboxRetrieveMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/web/inbox/retrieve', { method: 'POST' });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/webhook/status'] });
      toast({ title: t('common.success'), description: `Inbox retrieved: ${data?.processedCount || 0} messages processed` });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || 'Inbox retrieval failed', variant: 'destructive' });
    }
  });
  const dbStatusQuery = useQuery<{ success: boolean; tables: string[]; connection?: { host: string; port: string; database: string } }>({
    queryKey: ['/api/admin/db/status']
  });
  const runMigrationsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/db/migrate', { method: 'POST' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/db/status'] });
      toast({ title: t('common.success'), description: 'Migrations applied' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error.message || 'Migration failed', variant: 'destructive' });
    }
  });

  const secretsStatusQuery = useQuery<{ success: boolean; configured: Record<string, boolean> }>({
    queryKey: ['/api/admin/secrets/status']
  });
  const [groupReportDate, setGroupReportDate] = useState<string>('');
  const [groupReportTrigger, setGroupReportTrigger] = useState<number>(0);
  const exportGroupCsv = async (params: { groupId?: string; date?: string }) => {
    const q: string[] = [];
    if (params.groupId) q.push(`groupId=${encodeURIComponent(params.groupId)}`);
    if (params.date) q.push(`date=${encodeURIComponent(params.date)}`);
    const url = `/api/group/message-status-today.csv${q.length ? `?${q.join('&')}` : ''}`;
    const token = localStorage.getItem('token');
    const res = await fetch(url, {
      method: 'GET',
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        Accept: 'text/csv'
      }
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(text || `${res.status}`);
    }
    const blob = await res.blob();
    const href = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = href;
    a.download = `group-message-status-${params.date || 'today'}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(href);
  };
  const groupStatsQuery = useQuery<{ success: boolean; groupId: string | null; results: Array<{ user_id: string; user_name: string; email: string; sent_today: number; received_today: number }> }>({
    queryKey: ['/api/group/message-status-today', (profile?.user?.role === 'admin' ? (groupIdPricing || '' ) : 'me'), groupReportDate || '', groupReportTrigger],
    queryFn: async () => {
      const url = (profile?.user?.role === 'admin')
        ? (groupIdPricing ? `/api/group/message-status-today?groupId=${encodeURIComponent(groupIdPricing)}${groupReportDate ? `&date=${encodeURIComponent(groupReportDate)}` : ''}` : '')
        : `/api/group/message-status-today${groupReportDate ? `?date=${encodeURIComponent(groupReportDate)}` : ''}`;
      if (!url) return { success: false, groupId: null, results: [] } as any;
      const r = await apiRequest(url);
      return r.json();
    },
    enabled: groupReportTrigger > 0 && (profile?.user?.role === 'admin' ? !!groupIdPricing : !!profile?.user?.role),
  });
  const setWebhookUrlMutation = useMutation({
    mutationFn: async (url: string) => {
      return await apiRequest('/api/admin/webhook/set-url', { method: 'POST', body: JSON.stringify({ url }) });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/secrets/status'] });
      toast({ title: 'Success', description: 'Webhook URL updated' });
    },
    onError: (error: any) => {
      toast({ title: 'Error', description: error.message || 'Failed to set webhook URL', variant: 'destructive' });
    }
  });

  const [phraserConnStatus, setPhraserConnStatus] = useState<'unknown' | 'connected' | 'disconnected'>('unknown');
  const testPhraserMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/paraphraser/test');
    },
    onSuccess: (data: any) => {
      setPhraserConnStatus(data?.ok ? 'connected' : 'disconnected');
      toast({ title: data?.ok ? 'Connection Successful' : 'Connection Failed', description: data?.details || `${data?.provider || ''} not reachable`, variant: data?.ok ? undefined : 'destructive' });
    },
    onError: (error: any) => {
      setPhraserConnStatus('disconnected');
      toast({ title: 'Connection Failed', description: error?.message || 'Test failed', variant: 'destructive' });
    }
  });

  const [summaryEmail, setSummaryEmail] = useState('');
  const messagesSummaryMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/admin/messages/summary?email=${encodeURIComponent(summaryEmail)}`);
    },
    onSuccess: (data: any) => {
      if (!data?.found) {
        toast({ title: 'No user found', description: summaryEmail });
        return;
      }
      const c = data?.countEstimate ?? (data?.recent?.length || 0);
      toast({ title: `Found ${c} messages`, description: `User: ${data?.email}` });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || 'Summary failed', variant: 'destructive' });
    }
  });

  const diagnosticsQuery = useQuery<{ success: boolean; summary: any; checks: Array<{ name: string; status: string; details: any; durationMs: number }> }>({
    queryKey: ['/api/admin/diagnostics/run'],
    staleTime: 0,
    gcTime: 0,
  });
  const phraserConfigQuery = useQuery<{ success: boolean; provider: string; model: string; keyPresent: boolean; rules: any }>({ queryKey: ['/api/admin/paraphraser/config'] });
  const rotateSecretMutation = useMutation({
    mutationFn: async (key: string) => {
      return await apiRequest('/api/admin/secrets/rotate', { method: 'POST', body: JSON.stringify({ key }) });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/secrets/status'] });
      toast({ title: t('common.success'), description: 'Secret rotated' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error.message || 'Rotation failed', variant: 'destructive' });
    }
  });

  const webhookTestMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/webhook/test', {
        method: 'POST',
        body: JSON.stringify({ from: webhookFrom, business: webhookBusiness, message: webhookMessage, messageId: webhookMessageId || undefined })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/webhook/status'] });
      toast({ title: t('common.success'), description: 'Webhook simulated and stored' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error.message || 'Webhook simulation failed', variant: 'destructive' });
    }
  });

  const flowCheckMutation = useMutation({
    mutationFn: async () => {
      const params = new URLSearchParams({ business: flowBusiness });
      return await apiRequest(`/api/admin/webhook/flow-check?${params.toString()}`);
    },
    onSuccess: (data: any) => {
      toast({ title: t('common.success'), description: `Receiver ${data.receiver} → routed user ${data.routedUserId || 'none'}` });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error.message || 'Flow check failed', variant: 'destructive' });
    }
  });

  const { data: clientsData } = useQuery<{ success: boolean; clients: Array<{
    id: string;
    name: string;
    email: string;
    apiKey: string;
    status: string;
    isActive?: boolean;
    messagesSent: number;
    credits: string;
    lastActive: string;
    assignedPhoneNumbers: string[];
    rateLimitPerMinute: number;
    businessName: string | null;
    role?: string;
    groupId?: string | null;
    deliveryMode?: 'poll' | 'push' | 'both';
    webhookUrl?: string | null;
    webhookSecret?: string | null;
    passwordSetBy?: string | null;
    passwordSetAt?: string | null;
  }> }>({
    queryKey: ['/api/admin/clients']
  });

  const [phoneInputs, setPhoneInputs] = useState<Record<string, string>>({});
  useEffect(() => {
    const init: Record<string, string> = {};
    (clientsData?.clients || []).forEach(c => {
      init[c.id] = (c.assignedPhoneNumbers || []).join(', ');
    });
    setPhoneInputs(init);
  }, [clientsData]);

  const randomPhone = () => `+${Math.floor(100000 + Math.random() * 900000)}`;

  const updatePhoneNumbersMutation = useMutation({
    mutationFn: async ({ userId, phoneNumbers }: { userId: string; phoneNumbers: string }) => {
      return await apiRequest('/api/admin/update-phone-numbers', {
        method: 'POST',
        body: JSON.stringify({ userId, phoneNumbers })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({
        title: "Success",
        description: "Phone numbers updated successfully"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: t("admin.config.error.updatePhonesFailed"),
        variant: "destructive"
      });
    }
  });

  const updateRateLimitMutation = useMutation({
    mutationFn: async ({ userId, rateLimit }: { userId: string; rateLimit: number }) => {
      return await apiRequest('/api/admin/update-rate-limit', {
        method: 'POST',
        body: JSON.stringify({ userId, rateLimitPerMinute: rateLimit })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({
        title: t('common.success'),
        description: "Rate limit updated successfully"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update rate limit",
        variant: "destructive"
      });
    }
  });

  const updateBusinessNameMutation = useMutation({
    mutationFn: async ({ userId, businessName }: { userId: string; businessName: string }) => {
      const endpoint = (profile?.user?.role === 'supervisor') ? '/api/supervisor/update-business-name' : '/api/admin/update-business-name';
      return await apiRequest(endpoint, {
        method: 'POST',
        body: JSON.stringify({ userId, businessName })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({
        title: t('common.success'),
        description: "Business name updated successfully"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update business name",
        variant: "destructive"
      });
    }
  });

  const disableUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/admin/users/${userId}/disable`, { method: 'POST' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({ title: t('common.success'), description: 'User disabled and keys revoked' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to disable user', variant: 'destructive' });
    }
  });

  const enableUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/admin/users/${userId}/enable`, { method: 'POST' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({ title: t('common.success'), description: 'User enabled' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to enable user', variant: 'destructive' });
    }
  });

  const revokeUserKeysMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/admin/users/${userId}/revoke-keys`, { method: 'POST' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({ title: t('common.success'), description: 'All API keys revoked' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to revoke keys', variant: 'destructive' });
    }
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      return await apiRequest(`/api/v2/account/${userId}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      toast({ title: t('common.success'), description: 'User data cleared' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to delete user', variant: 'destructive' });
    }
  });

  const { data: statsData } = useQuery<{ success: boolean; totalMessages: number; totalClients: number }>({
    queryKey: ['/api/admin/stats']
  });

  const { data: recentActivity } = useQuery<{ 
    success: boolean; 
    logs: Array<{
      id: string;
      endpoint: string;
      clientName: string;
      timestamp: string;
      status: string;
      recipient: string;
    }>
  }>({
    queryKey: ['/api/admin/recent-activity'],
    refetchInterval: 5000 // Auto-refresh every 5 seconds
  });

  const { data: balanceData, isLoading: balanceLoading, error: balanceError } = useQuery<{ 
    success: boolean; 
    balance: number;
    currency: string;
  }>({
    queryKey: ['/api/admin/extremesms-balance'],
    refetchInterval: 30000, // Auto-refresh every 30 seconds
    retry: 2
  });

  const clients = clientsData?.clients || [];
  const isSupervisor = profile?.user?.role === 'supervisor';
  const totalMessages = statsData?.totalMessages || 0;
  const totalClients = statsData?.totalClients || clients.length;
  const extremeBalance = balanceData?.balance ?? null;
  const balanceCurrency = balanceData?.currency || 'USD';
  const sumCredits = clients.reduce((sum, c) => sum + (parseFloat(c.credits || '0') || 0), 0);
  const myGroupId = clients.find(c => c.id === profile?.user?.id)?.groupId || null;
  // Group pool from system_config (fallback to sum of supervisor credits)
  const { data: groupPool } = useQuery<{ success: boolean; groupId: string; credits: number | null } | { success: boolean; pools: Array<{ groupId: string; credits: number }> }>({
    queryKey: ['/api/group/pool', myGroupId || ''],
    queryFn: async () => {
      if (!myGroupId) return { success: true, groupId: '', credits: null } as any;
      const r = await apiRequest(`/api/group/pool?groupId=${encodeURIComponent(myGroupId)}`);
      return r.json();
    },
    refetchInterval: 10000,
    enabled: !!myGroupId && profile?.user?.role !== undefined
  });
  const groupPoolCredits = (groupPool as any)?.credits;
  const groupSupervisorCredits = typeof groupPoolCredits === 'number' && !isNaN(groupPoolCredits)
    ? groupPoolCredits
    : clients
      .filter(c => c.groupId && myGroupId && c.groupId === myGroupId && c.role === 'supervisor')
      .reduce((sum, c) => sum + (parseFloat(c.credits || '0') || 0), 0);
  const groupClientCredits = clients
    .filter(c => c.groupId && myGroupId && c.groupId === myGroupId && c.role !== 'supervisor')
    .reduce((sum, c) => sum + (parseFloat(c.credits || '0') || 0), 0);
  const groupRemainingCredits = Math.max(groupSupervisorCredits - groupClientCredits, 0);
  const clientRateNumber = parseFloat(clientRate || config?.config?.client_rate_per_sms || '0') || 0;
  const creditsValueUSD = (sumCredits * clientRateNumber).toFixed(2);
  const extremeUSD = (extremeBalance !== null) ? (extremeBalance * (parseFloat(extremeCost || '0') || 0)).toFixed(2) : null;

  const syncCreditsMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/credits/sync', { method: 'POST' });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/extremesms-balance'] });
      toast({ title: t('common.success'), description: t('admin.syncCredits.success').replace('{count}', String(data.adjustedCount || 0)) });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || t('admin.syncCredits.failed'), variant: 'destructive' });
    }
  });

  const recalcBalancesMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('/api/admin/recalculate-balances', { method: 'POST' });
    },
    onSuccess: async (resp: any) => {
      try {
        queryClient.invalidateQueries({ queryKey: ['/api/group/pool'] });
        queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
        queryClient.invalidateQueries({ queryKey: ['/api/admin/extremesms-balance'] });
      } catch {}
      toast({ title: t('common.success'), description: 'Balances recalculated' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || 'Failed to recalculate', variant: 'destructive' });
    }
  });

  const groupPricingAllQuery = useQuery<{ success: boolean; base: { extremeCost: number; clientRate: number }; groups: Array<{ groupId: string; name: string | null; extremeCost?: number; clientRate?: number; margin?: number }> }>({
    queryKey: ['/api/admin/pricing/all'],
    enabled: profile?.user?.role === 'admin'
  });
  const deleteGroupPricingMutation = useMutation({
    mutationFn: async (groupId: string) => {
      return await apiRequest(`/api/admin/pricing/group/${encodeURIComponent(groupId)}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/pricing/all'] });
      toast({ title: t('common.success'), description: 'Group pricing deleted; reverted to base.' });
    },
    onError: (error: any) => {
      toast({ title: t('common.error'), description: error?.message || 'Failed to delete group pricing', variant: 'destructive' });
    }
  });

  function GroupPricingTable() {
    if (profile?.user?.role !== 'admin') return null;
    const rows = groupPricingAllQuery.data?.groups || [];
    return (
      <div className="mt-4">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Group ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Extreme Cost</TableHead>
              <TableHead>Client Rate</TableHead>
              <TableHead>Margin</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground">No group pricing configured</TableCell></TableRow>
            ) : rows.map(g => (
              <TableRow key={g.groupId}>
                <TableCell className="font-mono">{g.groupId}</TableCell>
                <TableCell>{g.name || '-'}</TableCell>
                <TableCell>{g.extremeCost !== undefined ? g.extremeCost.toFixed(4) : '-'}</TableCell>
                <TableCell>{g.clientRate !== undefined ? g.clientRate.toFixed(4) : '-'}</TableCell>
                <TableCell>{g.margin !== undefined ? g.margin.toFixed(4) : '-'}</TableCell>
                <TableCell>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deleteGroupPricingMutation.mutate(g.groupId)}
                    data-testid={`button-delete-group-pricing-${g.groupId}`}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="col-span-1">
            <Label>Group Supervisor Pool (credits)</Label>
            <div className="flex items-center gap-2 mt-2">
              <Select value={groupIdPricing || ''} onValueChange={(v) => setGroupIdPricing(v)}>
                <SelectTrigger data-testid="select-pool-group">
                  <SelectValue placeholder="Select Group ID" />
                </SelectTrigger>
                <SelectContent>
                  {(clients || []).map(c => c.groupId).filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).map(g => (
                    <SelectItem key={String(g)} value={String(g)} textValue={String(g)}>{String(g)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input type="number" step="0.01" placeholder="Credits" value={groupExtremeCost /* temp hold to reuse input state */} onChange={(e) => setGroupExtremeCost(e.target.value)} />
              <Button
                type="button"
                variant="outline"
                disabled={!groupIdPricing}
                onClick={async () => {
                  const val = parseFloat(groupExtremeCost);
                  if (isNaN(val)) { toast({ title: t('common.error'), description: 'Enter credits', variant: 'destructive' }); return; }
                  await apiRequest('/api/admin/group/pool', { method: 'POST', body: JSON.stringify({ groupId: groupIdPricing, credits: val }) });
                  queryClient.invalidateQueries({ queryKey: ['/api/admin/group/pool', groupIdPricing] });
                  toast({ title: t('common.success'), description: 'Group pool updated' });
                }}
              >Save Pool</Button>
            </div>
            <div className="text-xs text-muted-foreground mt-1">Pool is used for supervisor overview; per-account credits remain attached.</div>
          </div>
        </div>
      </div>
    );
  }

  const [autoSyncInterval, setAutoSyncInterval] = useState<number>(() => {
    const saved = Number(localStorage.getItem('autoSyncInterval'));
    return (saved && saved >= 120000 && saved <= 3600000) ? saved : 300000;
  });
  useEffect(() => {
    localStorage.setItem('autoSyncInterval', String(autoSyncInterval));
  }, [autoSyncInterval]);
  useEffect(() => {
    if (profile?.user?.role !== 'admin') return;
    const id = setInterval(() => {
      try { syncCreditsMutation.mutate(); } catch {}
    }, autoSyncInterval);
    return () => clearInterval(id);
  }, [autoSyncInterval, profile?.user?.role]);

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    saveConfigMutation.mutate({
      extremeApiKey,
      extremeCost,
      clientRate,
      timezone,
      adminDefaultBusinessId: webhookBusiness || 'IBS_0',
      signupSeedExamples
    });
  };

  

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader />
      <div className="p-6 space-y-6">
        
        <div className="flex items-center gap-4">
          <Link href={isSupervisor ? "/adminsup" : (profile?.user?.role === 'admin' ? "/admin" : "/dashboard")}>
            <Button size="icon" data-testid="button-back" className="bg-blue-600 text-white hover:bg-blue-700 font-bold">
              <ArrowLeft className="h-5 w-5" strokeWidth={3} />
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-bold tracking-tight">{isSupervisor ? t('supervisor.title') : t('admin.title')}</h1>
            <p className="text-muted-foreground mt-2">{isSupervisor ? t('supervisor.subtitle') : t('admin.subtitle')}</p>
          </div>
          {profile?.user?.role === 'admin' && (
            <div className="ml-auto flex items-center gap-2">
              <Button variant="outline" onClick={() => inboxRetrieveMutation.mutate()} disabled={inboxRetrieveMutation.isPending}>
                {inboxRetrieveMutation.isPending ? 'Retrieving…' : 'Retrieve Inbox Now'}
              </Button>
              <Button variant="secondary" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/admin/webhook/status'] })}>Refresh Webhook Status</Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title={t('admin.stats.totalClients')}
            value={totalClients}
            icon={Users}
            description={t('admin.stats.activeAccounts')}
          />
          <StatCard
            title={t('admin.stats.totalMessages')}
            value={totalMessages.toLocaleString()}
            icon={Activity}
            description={t('admin.stats.last30Days')}
          />
          <StatCard
            title={t('admin.stats.systemStatus')}
            value={t('admin.stats.healthy')}
            icon={Settings}
            description={t('admin.stats.allRunning')}
          />
          <StatCard
            title={'User'}
            value={(profile as any)?.user?.email || profile?.user?.id || ''}
            icon={Users}
            description={'Logged in account'}
          />
          <Card className="md:col-span-2 lg:col-span-4">
            <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <p className="text-sm font-medium text-muted-foreground">Credits Overview</p>
                  <div className="flex items-center gap-2">
                    {profile?.user?.role === 'admin' && (
                      <Button
                        size="sm"
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                        onClick={async () => {
                          try {
                            const r1 = await apiRequest('/api/admin/reconcile-credits', { method: 'POST' });
                            await apiRequest('/api/admin/recalculate-balances', { method: 'POST' });
                            queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
                            queryClient.invalidateQueries({ queryKey: ['/api/group/pool'] });
                            queryClient.invalidateQueries({ queryKey: ['/api/admin/extremesms-balance'] });
                            const reconciled = Number(r1?.reconciled || 0);
                            toast({ title: t('common.success'), description: reconciled > 0 ? `Reconciled ${reconciled} accounts` : 'Reconcile up to date' });
                          } catch (e: any) {
                            toast({ title: t('common.error'), description: e?.message || 'Reconcile failed', variant: 'destructive' });
                          }
                        }}
                        data-testid="button-reconcile"
                      >
                        Reconcile
                      </Button>
                    )}
                    <div className="p-3 rounded-lg bg-primary/10"><Wallet className="w-5 h-5 text-primary" /></div>
                  </div>
                </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-4">
                <div>
                  <p className="text-xs text-muted-foreground">IbikiSMS Balance</p>
                  <p className="text-2xl font-bold tracking-tight mt-1">
                    {isSupervisor
                      ? `${groupSupervisorCredits.toFixed(2)} credits`
                      : (balanceLoading ? 'Loading...' : balanceError ? 'Unavailable' : (
                          extremeBalance !== null ? `${extremeBalance.toLocaleString()} credits` : 'N/A'
                        ))}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isSupervisor ? 'Pooled balance for supervisors in your group' : 'Current account balance'}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">SMS capacity: {isSupervisor ? Math.floor(groupSupervisorCredits).toLocaleString() : (extremeBalance !== null ? Math.floor(extremeBalance).toLocaleString() : '0')} messages</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Allocated Credits</p>
                  <p className={`text-2xl font-bold tracking-tight mt-1 ${isSupervisor ? 'text-green-600' : (extremeBalance !== null && Math.abs((extremeBalance - sumCredits)) <= 0.01 ? 'text-green-600' : 'text-red-600')}`}>
                    {(isSupervisor ? groupClientCredits : sumCredits).toFixed(2)} credits
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Sum of all client credits</p>
                  <p className="text-xs text-muted-foreground mt-1">SMS capacity: {Math.floor(isSupervisor ? groupClientCredits : sumCredits).toLocaleString()} messages</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Remaining Credits</p>
                  <p className={`text-2xl font-bold tracking-tight mt-1 ${isSupervisor ? (groupRemainingCredits >= 0 ? 'text-green-600' : 'text-red-600') : (extremeBalance !== null && Math.abs((extremeBalance - sumCredits)) <= 0.01 ? 'text-green-600' : 'text-red-600')}`}>
                    {isSupervisor
                      ? `${groupRemainingCredits.toFixed(2)} credits`
                      : (extremeBalance !== null ? `${Math.max(extremeBalance - sumCredits, 0).toFixed(2)} credits` : 'N/A')}
                  </p>
                  <p className={`text-xs mt-1 ${isSupervisor ? (groupRemainingCredits >= 0 ? 'text-green-700' : 'text-red-700') : (extremeBalance !== null && Math.abs((extremeBalance - sumCredits)) <= 0.01 ? 'text-green-700' : 'text-red-700')}`}>{isSupervisor ? 'Supervisor pooled minus allocated (group)' : (extremeBalance !== null && Math.abs((extremeBalance - sumCredits)) <= 0.01 ? 'In Sync' : 'Needs Reconcile')}</p>
                  <p className="text-xs text-muted-foreground mt-1">SMS capacity: {isSupervisor ? Math.floor(groupRemainingCredits).toLocaleString() : (extremeBalance !== null ? Math.floor(Math.max(extremeBalance - sumCredits, 0)).toLocaleString() : '0')} messages</p>
                </div>
              </div>
              <div className="mt-3 p-3 rounded border bg-muted/40 text-xs text-muted-foreground">1 credit = 1 SMS. Capacity is based on credits only.</div>
              </CardContent>
            </Card>
          </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="hover-elevate active-elevate-2 cursor-pointer border-2 border-blue-500/30">
            <Link href="/send-sms">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Send className="h-5 w-5" />
                  {t('sendSms.title')}
                </CardTitle>
                <CardDescription>
                  {t('sendSms.subtitle')}
                </CardDescription>
              </CardHeader>
            </Link>
          </Card>
          <Card className="hover-elevate active-elevate-2 cursor-pointer border-2 border-blue-500/30">
            <Link href="/inbox">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <InboxIcon className="h-5 w-5" />
                    {t('inbox.title')}
                  </CardTitle>
                  <Link href="/inbox?view=favorites">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 px-2 text-xs bg-yellow-100 text-yellow-800 border border-yellow-500 hover:bg-yellow-200 flex items-center gap-1"
                      title="★ Favourites"
                    >
                      <Star className="h-3 w-3" />
                      {t('inbox.favorites')}
                    </Button>
                  </Link>
                </div>
                <CardDescription>
                  View and reply to incoming messages
                </CardDescription>
              </CardHeader>
            </Link>
          </Card>
          <Card className="hover-elevate active-elevate-2 cursor-pointer border-2 border-blue-500/30">
            <Link href="/contacts">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Contacts
                </CardTitle>
                <CardDescription>
                  Manage your contact list
                </CardDescription>
              </CardHeader>
            </Link>
          </Card>
          <Card className="hover-elevate active-elevate-2 cursor-pointer border-2 border-blue-500/30">
            <Link href="/message-history">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Message History
                </CardTitle>
                <CardDescription>
                  Track delivery status and history
                </CardDescription>
              </CardHeader>
            </Link>
          </Card>
        </div>

        {/* Create User moved to its own tab */}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <WorldClock />
          <MessageStatusChart />
        </div>
        <MessageStatusTiles />
        {false && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Ibiki Phraser Settings</CardTitle>
              <CardDescription>Configure the paraphrase provider and model.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <Label>Provider</Label>
                <Select defaultValue={phraserConfigQuery.data?.provider || 'openrouter'} onValueChange={async (v) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: v }) });
                  toast({ title: t('common.success'), description: 'Provider updated' });
                }}>
                  <SelectTrigger className="w-48"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openrouter" textValue="OpenRouter">OpenRouter</SelectItem>
                    <SelectItem value="remote" textValue="Remote HTTP">Remote HTTP</SelectItem>
                    <SelectItem value="ollama" textValue="Local (Ollama)">Local (Ollama)</SelectItem>
                    <SelectItem value="stub" textValue="Built-in">Built-in</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="secondary" onClick={async () => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: 'openrouter', openrouterModel: 'qwen/qwen3-coder:free' }) });
                  phraserConfigQuery.refetch?.();
                  toast({ title: t('common.success'), description: 'Set to Qwen3 Coder (free)' });
                }}>Use Qwen3 Coder (free)</Button>
                <Button variant="secondary" onClick={async () => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: 'openrouter', openrouterModel: 'alibaba/tongyi-deepresearch-30b-a3b:free' }) });
                  toast({ title: t('common.success'), description: 'Set to Tongyi DeepResearch (free)' });
                }} className="ml-2">Use Tongyi DeepResearch (free)</Button>
              </div>
              <div className="flex items-center gap-3">
                <Label>Model</Label>
                <Input placeholder="x-ai/grok-4.1-fast:free" defaultValue={phraserConfigQuery.data?.model || 'x-ai/grok-4.1-fast:free'} onBlur={async (e) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ openrouterModel: e.target.value }) });
                  toast({ title: t('common.success'), description: 'Model saved' });
                }} />
              </div>
              <div className="flex items-center gap-3">
                <Label>OpenRouter Key</Label>
                <Input type="password" placeholder="Bearer sk-or-..." onBlur={async (e) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ openrouterKey: e.target.value }) });
                  toast({ title: t('common.success'), description: 'Key saved' });
                }} />
              </div>
              <div className="text-xs text-muted-foreground">Placeholders like {'{'}{'{'}name{'}'}{'}'} and URLs are preserved automatically.</div>
              <div className="flex items-center gap-3">
                <Button variant="outline" onClick={() => testPhraserMutation.mutate()} disabled={testPhraserMutation.isPending} data-testid="button-test-phraser">
                  {testPhraserMutation.isPending ? 'Testing...' : 'Test Connection'}
                </Button>
                {phraserConnStatus !== 'unknown' && (
                  <Badge variant={phraserConnStatus === 'connected' ? 'default' : 'destructive'}>
                    {phraserConnStatus === 'connected' ? '✓ Connected' : '✗ Disconnected'}
                  </Badge>
                )}
              </div>
              <Accordion type="single" collapsible>
                <AccordionItem value="phraser-advanced">
                  <AccordionTrigger>Advanced Settings</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Target Min</Label>
                        <Input type="number" defaultValue={145} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ targetMin: parseInt(e.target.value||'145') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Target Max</Label>
                        <Input type="number" defaultValue={155} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ targetMax: parseInt(e.target.value||'155') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Hard Max</Label>
                        <Input type="number" defaultValue={160} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ maxChars: parseInt(e.target.value||'160') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Enforce Grammar</Label>
                        <Switch defaultChecked onCheckedChange={async (v)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ enforceGrammar: v })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="col-span-1 md:col-span-2">
                        <Label>Link Template</Label>
                        <Input defaultValue={'Here is the link ${url} here you will find all the information you were asking for.'} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ linkTemplate: e.target.value })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                        <div className="text-xs text-muted-foreground mt-1">Use ${'url'} placeholder.</div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        )}

        {false && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>User Message Summary</CardTitle>
              <CardDescription>Resolve a user by email and view recent logs.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Input placeholder="user@example.com" value={summaryEmail} onChange={(e)=> setSummaryEmail(e.target.value)} className="w-80" />
                <Button onClick={()=> messagesSummaryMutation.mutate()} disabled={!summaryEmail || messagesSummaryMutation.isPending}>
                  {messagesSummaryMutation.isPending ? 'Loading...' : 'Check'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {false && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Ibiki Diagnostics</CardTitle>
              <CardDescription>Run system checks and view results.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-3">
                <Button onClick={() => diagnosticsQuery.refetch?.()} data-testid="button-run-diagnostics">
                  {diagnosticsQuery.isFetching ? 'Running…' : 'Run Diagnostics'}
                </Button>
                {diagnosticsQuery.data && (
                  <Button variant="outline" onClick={() => navigator.clipboard.writeText(JSON.stringify(diagnosticsQuery.data, null, 2))}>Copy JSON</Button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(diagnosticsQuery.data?.checks || []).map((c: any, i: number) => (
                  <Card key={`diag-${i}`} className={c.status === 'pass' ? 'border-green-300' : 'border-red-300'}>
                    <CardHeader>
                      <CardTitle className="text-sm">{c.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs">Status: {c.status}</div>
                      <div className="text-xs">Duration: {c.durationMs}ms</div>
                      <pre className="mt-2 text-xs bg-muted/40 p-2 rounded overflow-auto max-h-[24vh]">{JSON.stringify(c.details, null, 2)}</pre>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="clients" data-testid="tabs-admin">
          <TabsList>
            <TabsTrigger value="clients" data-testid="tab-clients">{t('admin.tabs.clients')}</TabsTrigger>
            {profile?.user?.role === 'admin' ? (
              <>
                <TabsTrigger value="configuration" data-testid="tab-configuration">{t('admin.tabs.configuration')}</TabsTrigger>
                <TabsTrigger value="webhook" data-testid="tab-webhook">{t('admin.tabs.webhook')}</TabsTrigger>
                <TabsTrigger value="testing" data-testid="tab-testing">{t('admin.tabs.testing')}</TabsTrigger>
                <TabsTrigger value="monitoring" data-testid="tab-monitoring">{t('admin.tabs.monitoring')}</TabsTrigger>
                <TabsTrigger value="actionlogs" data-testid="tab-actionlogs">{t('admin.actionLogs')}</TabsTrigger>
                <TabsTrigger value="messages" data-testid="tab-messages">Message Activity</TabsTrigger>
                <TabsTrigger value="createuser" data-testid="tab-createuser">{t('admin.tabs.createUser') || 'User Create'}</TabsTrigger>
                <TabsTrigger value="phraser" data-testid="tab-phraser">Ibiki Phraser</TabsTrigger>
                <TabsTrigger value="usersummary" data-testid="tab-usersummary">User Summary</TabsTrigger>
                <TabsTrigger value="groupreport" data-testid="tab-groupreport">Group Report</TabsTrigger>
                <TabsTrigger value="diagnostics" data-testid="tab-diagnostics">Diagnostics</TabsTrigger>
              </>
            ) : (
              <>
                <TabsTrigger value="actionlogs" data-testid="tab-actionlogs">{t('admin.actionLogs')}</TabsTrigger>
                <TabsTrigger value="messages" data-testid="tab-messages">Message Activity</TabsTrigger>
                <TabsTrigger value="createuser" data-testid="tab-createuser">{t('admin.tabs.createUser') || 'User Create'}</TabsTrigger>
                <TabsTrigger value="groupreport" data-testid="tab-groupreport">Group Report</TabsTrigger>
              </>
            )}
          </TabsList>

        <TabsContent value="clients" className="space-y-4">
          <div className="bg-muted/50 rounded p-3 text-xs">
            <div className="font-semibold mb-2">Delivery Mode Key</div>
            <div>Poll: Dashboard fetches inbox periodically; no external webhook needed.</div>
            <div>Push: System posts incoming messages to client's configured webhook URL.</div>
            <div>Both: Enable polling and webhook delivery together for redundancy.</div>
          </div>
          <Card className="border border-border/60">
            <CardHeader>
              <CardTitle>Client Management</CardTitle>
              <CardDescription>View and manage all connected clients</CardDescription>
            </CardHeader>
            <CardContent>
              <Table className="text-sm">
                <TableHeader>
                  <TableRow>
                    <TableHead className="whitespace-nowrap text-center">Client Name</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Email</TableHead>
                    <TableHead className="whitespace-nowrap text-center">API Key</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Status</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Messages</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Credits</TableHead>
                    <TableHead className="text-center">{t('admin.clients.table.rateLimit')}</TableHead>
                    <TableHead className="text-center">{t('admin.clients.table.businessName')}</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Assigned Numbers</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Last Active</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Delivery</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Webhook</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Role</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Group ID</TableHead>
                    <TableHead className="whitespace-nowrap text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {clients.map((client) => (
                    <TableRow key={client.id} data-testid={`row-client-${client.id}`} className="align-middle">
                      <TableCell className="font-medium py-2">{client.name}</TableCell>
                      <TableCell className="py-2">{client.email}</TableCell>
                      <TableCell className="font-mono text-[11px] max-w-[12rem] truncate py-2">
                        {client.apiKey}
                        <Button size="sm" variant="ghost" className="ml-2 px-2 h-6" onClick={() => alert(client.apiKey)}>View</Button>
                      </TableCell>
                      <TableCell className="py-2">
                        <Badge variant={(client.isActive ?? client.status === "active") ? "default" : "secondary"}>
                          {(client.isActive ?? client.status === "active") ? 'active' : 'disabled'}
                        </Badge>
                      </TableCell>
                      <TableCell className="py-2">{client.messagesSent.toLocaleString()}</TableCell>
                      <TableCell className="py-2">
                        <div className="space-y-1">
                          <span className="font-mono font-semibold" data-testid={`text-credits-${client.id}`}>
                            {parseFloat(client.credits || '0').toFixed(2)} credits
                          </span>
                          {profile?.user?.role === 'admin' && (
                            <div className="text-xs text-muted-foreground">
                              ≈ ${ ( (parseFloat(client.credits || '0') || 0) * clientRateNumber ).toFixed(2) } USD
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          placeholder="200"
                          defaultValue={client.rateLimitPerMinute}
                          onBlur={(e) => {
                            const newLimit = parseInt(e.target.value);
                            if (!isNaN(newLimit) && newLimit !== client.rateLimitPerMinute) {
                              updateRateLimitMutation.mutate({ 
                                userId: client.id, 
                                rateLimit: newLimit 
                              });
                            }
                          }}
                          className="w-20 h-8"
                          data-testid={`input-rate-limit-${client.id}`}
                          title={t('admin.clients.rateLimit.description')}
                          min="1"
                          max="10000"
                          disabled={profile?.user?.role === 'supervisor'}
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="text"
                          placeholder={t('admin.clients.businessName.placeholder')}
                          defaultValue={client.businessName || ''}
                          onBlur={(e) => {
                            const newBusinessName = e.target.value.trim();
                            const currentBusinessName = client.businessName || '';
                            if (newBusinessName !== currentBusinessName) {
                              updateBusinessNameMutation.mutate({ 
                                userId: client.id, 
                                businessName: newBusinessName 
                              });
                            }
                          }}
                          className="w-32 h-8"
                          data-testid={`input-business-name-${client.id}`}
                          title={t('admin.clients.businessName.description')}
                          disabled={profile?.user?.role === 'supervisor'}
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Input
                            type="text"
                            placeholder="+123456, +234567"
                            value={phoneInputs[client.id] ?? (client.assignedPhoneNumbers || []).join(', ')}
                            onChange={(e) => setPhoneInputs(p => ({ ...p, [client.id]: e.target.value }))}
                            onBlur={(e) => {
                              const newPhones = e.target.value.trim();
                              const currentPhones = (client.assignedPhoneNumbers || []).join(', ');
                              if (newPhones !== currentPhones) {
                                updatePhoneNumbersMutation.mutate({ 
                                  userId: client.id, 
                                  phoneNumbers: newPhones 
                                });
                              }
                            }}
                            className="w-40 h-8 font-mono text-[11px]"
                            data-testid={`input-phones-${client.id}`}
                            title="Enter multiple numbers separated by commas"
                            disabled={profile?.user?.role === 'supervisor'}
                          />
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              const next = randomPhone();
                              setPhoneInputs(p => {
                                const current = (p[client.id] ?? (client.assignedPhoneNumbers || []).join(', ')).trim();
                                const updated = current ? `${current}, ${next}` : next;
                                updatePhoneNumbersMutation.mutate({ userId: client.id, phoneNumbers: updated });
                                return { ...p, [client.id]: updated };
                              });
                            }}
                            className="h-8"
                            disabled={profile?.user?.role === 'supervisor'}
                          >
                            Random
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground py-2">{client.lastActive}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <select
                            className="border rounded px-2 py-1 text-xs"
                            defaultValue={(client.deliveryMode || 'poll') as any}
                            onChange={(e) => setEditDeliveryMode(e.target.value as any)}
                            disabled={profile?.user?.role === 'supervisor'}
                          >
                            <option value="poll">Poll</option>
                            <option value="push">Push</option>
                            <option value="both">Both</option>
                          </select>
                          <Button size="sm" variant="outline" disabled={profile?.user?.role === 'supervisor'} onClick={() => {
                            apiRequest(`/api/admin/clients/${client.id}/delivery-mode`, { method: 'POST', body: JSON.stringify({ mode: editDeliveryMode }) })
                              .then(() => queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] }));
                          }} className="h-7 px-2 text-xs">Save</Button>
                        </div>
                      </TableCell>
                      <TableCell className="py-2">
                        <div className="w-40 flex items-center justify-center gap-2">
                          <WebhookEditDialog clientId={client.id} currentUrl={client.webhookUrl} currentSecret={client.webhookSecret} triggerLabel="URL" buttonVariant="outline" buttonClassName="h-8 px-3 text-xs rounded" />
                          <WebhookEditDialog clientId={client.id} currentUrl={client.webhookUrl} currentSecret={client.webhookSecret} triggerLabel="Secret" buttonVariant="outline" buttonClassName="h-8 px-3 text-xs rounded" />
                        </div>
                      </TableCell>
                      <TableCell className="py-2">
                          <select defaultValue={client.role || 'client'} className="border rounded px-2 py-1 text-xs h-8" onChange={(e) => {
                            const nextRole = e.target.value;
                            apiRequest(`/api/admin/users/${client.id}/role`, { method: 'POST', body: JSON.stringify({ role: nextRole }) })
                              .then(() => {
                                queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
                                toast({ title: 'Saved', description: 'Role updated' });
                              })
                              .catch((err: any) => {
                                toast({ title: 'Error', description: err?.message || 'Failed to update role', variant: 'destructive' });
                              });
                          }}>
                            <option value="admin">Admin</option>
                            <option value="supervisor">Supervisor</option>
                            <option value="client">User</option>
                          </select>
                      </TableCell>
                      <TableCell className="py-2">
                          <Input defaultValue={client.groupId || ''} placeholder="GROUP-ID" className="w-32 h-8 text-xs" onBlur={(e) => {
                            const v = e.target.value.trim();
                            apiRequest(`/api/admin/users/${client.id}/group`, { method: 'POST', body: JSON.stringify({ groupId: v }) })
                              .then(() => {
                                queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
                                toast({ title: 'Saved', description: 'Group ID updated' });
                              })
                              .catch((err: any) => {
                                toast({ title: 'Error', description: err?.message || 'Failed to update group', variant: 'destructive' });
                              });
                          }} onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              const v = (e.target as HTMLInputElement).value.trim();
                              apiRequest(`/api/admin/users/${client.id}/group`, { method: 'POST', body: JSON.stringify({ groupId: v }) })
                                .then(() => {
                                  queryClient.invalidateQueries({ queryKey: ['/api/admin/clients'] });
                                  toast({ title: 'Saved', description: 'Group ID updated' });
                                })
                                .catch((err: any) => {
                                  toast({ title: 'Error', description: err?.message || 'Failed to update group', variant: 'destructive' });
                                });
                            }
                          }} />
                      </TableCell>
                      <TableCell className="align-top py-2">
                        <div className="grid grid-cols-2 md:grid-cols-1 gap-2 items-start min-w-[12rem]">
                          <AddCreditsToClientDialog 
                            clientId={client.id}
                            clientName={client.name}
                            currentCredits={client.credits}
                            groupId={client.groupId}
                            showUSD={profile?.user?.role === 'admin'}
                            showAvailableRemaining={profile?.user?.role === 'admin'}
                            triggerMode="add"
                            triggerLabel="$ Add"
                            buttonVariant="default"
                            buttonClassName="w-full h-7 justify-center bg-green-600 text-white hover:bg-green-700 border border-green-700 text-xs"
                          />
                          <AddCreditsToClientDialog 
                            clientId={client.id}
                            clientName={client.name}
                            currentCredits={client.credits}
                            groupId={client.groupId}
                            showUSD={profile?.user?.role === 'admin'}
                            showAvailableRemaining={profile?.user?.role === 'admin'}
                            triggerMode="deduct"
                            triggerLabel="$ Deduct"
                            buttonVariant="outline"
                            buttonClassName="w-full h-7 justify-center bg-orange-100 text-orange-800 border border-orange-500 hover:bg-orange-200 text-xs"
                          />
                          {!(client.isActive ?? client.status === 'active') ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => enableUserMutation.mutate(client.id)}
                              data-testid={`button-enable-${client.id}`}
                            className="h-7 px-2 text-xs">
                              Enable
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => disableUserMutation.mutate(client.id)}
                              data-testid={`button-disable-${client.id}`}
                            className="h-7 px-2 text-xs">
                              Disable
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => revokeUserKeysMutation.mutate(client.id)}
                            data-testid={`button-revoke-keys-${client.id}`}
                          className="h-7 px-2 text-xs">
                            Revoke Keys
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              const msg = 'This action will totally remove the user profile from Ibiki, this action is irreversible.\n\nProceed to PURGE this user?';
                              if (confirm(msg)) {
                                deleteUserMutation.mutate(client.id);
                              }
                            }}
                            data-testid={`button-purge-${client.id}`}
                          className="h-7 px-2 text-xs">
                            Purge
                          </Button>
                          <div className="text-[10px]">
                            {client.passwordSetBy ? (
                              <div>
                                <div>Set by {client.passwordSetBy}</div>
                                <span className="inline-block px-2 py-0.5 rounded bg-green-100 text-green-800 text-[10px]">PWD set</span>
                              </div>
                            ) : null}
                          </div>
                          {/* Reset Password */}
                          {client.role !== 'admin' && (
                            <div className="flex justify-center">
                              {/* @ts-ignore */}
                              <ResetPasswordDialog clientId={client.id} clientName={client.name} />
                            </div>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="phraser" className="space-y-4">
          <Card className="mt-2">
            <CardHeader>
              <CardTitle>Ibiki Phraser Settings</CardTitle>
              <CardDescription>Configure the paraphrase provider and model.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3">
                <Label>Provider</Label>
                <Select defaultValue="openrouter" onValueChange={async (v) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: v }) });
                  toast({ title: t('common.success'), description: 'Provider updated' });
                }}>
                  <SelectTrigger className="w-48"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openrouter" textValue="OpenRouter">OpenRouter</SelectItem>
                    <SelectItem value="remote" textValue="Remote HTTP">Remote HTTP</SelectItem>
                    <SelectItem value="ollama" textValue="Local (Ollama)">Local (Ollama)</SelectItem>
                    <SelectItem value="stub" textValue="Built-in">Built-in</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="secondary" onClick={async () => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: 'openrouter', openrouterModel: 'qwen/qwen3-coder:free' }) });
                  toast({ title: t('common.success'), description: 'Set to Qwen3 Coder (free)' });
                }}>Use Qwen3 Coder (free)</Button>
                <Button variant="secondary" className="ml-2" onClick={async () => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ provider: 'openrouter', openrouterModel: 'alibaba/tongyi-deepresearch-30b-a3b:free' }) });
                  phraserConfigQuery.refetch?.();
                  toast({ title: t('common.success'), description: 'Set to Tongyi DeepResearch (free)' });
                }}>Use Tongyi DeepResearch (free)</Button>
              </div>
              <div className="flex items-center gap-3">
                <Label>Model</Label>
                <Input placeholder="qwen/qwen3-coder:free" defaultValue={phraserConfigQuery.data?.model || 'qwen/qwen3-coder:free'} onBlur={async (e) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ openrouterModel: e.target.value }) });
                  phraserConfigQuery.refetch?.();
                  toast({ title: t('common.success'), description: 'Model saved' });
                }} />
              </div>
              <div className="flex items-center gap-3">
                <Label>OpenRouter Key</Label>
                <Input type="password" placeholder="Bearer sk-or-..." onBlur={async (e) => {
                  await apiRequest('/api/admin/paraphraser/config', { method: 'POST', body: JSON.stringify({ openrouterKey: e.target.value }) });
                  toast({ title: t('common.success'), description: 'Key saved' });
                }} />
              </div>
              <div className="flex items-center gap-3">
                <Button variant="outline" onClick={() => testPhraserMutation.mutate()} disabled={testPhraserMutation.isPending} data-testid="button-test-phraser">
                  {testPhraserMutation.isPending ? 'Testing...' : 'Test Connection'}
                </Button>
                {phraserConnStatus !== 'unknown' && (
                  <Badge variant={phraserConnStatus === 'connected' ? 'default' : 'destructive'}>
                    {phraserConnStatus === 'connected' ? '✓ Connected' : '✗ Disconnected'}
                  </Badge>
                )}
              </div>
              <Accordion type="single" collapsible>
                <AccordionItem value="phraser-advanced">
                  <AccordionTrigger>Advanced Settings</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Target Min</Label>
                        <Input type="number" defaultValue={145} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ targetMin: parseInt(e.target.value||'145') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Target Max</Label>
                        <Input type="number" defaultValue={155} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ targetMax: parseInt(e.target.value||'155') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Hard Max</Label>
                        <Input type="number" defaultValue={160} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ maxChars: parseInt(e.target.value||'160') })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="min-w-[140px]">Enforce Grammar</Label>
                        <Switch defaultChecked onCheckedChange={async (v)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ enforceGrammar: v })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                      </div>
                      <div className="col-span-1 md:col-span-2">
                        <Label>Link Template</Label>
                        <Input defaultValue={'Here is the link ${url} here you will find all the information you were asking for.'} onBlur={async (e)=>{ await apiRequest('/api/admin/paraphraser/config',{ method:'POST', body: JSON.stringify({ linkTemplate: e.target.value })}); toast({ title: t('common.success'), description: 'Saved' }); }} />
                        <div className="text-xs text-muted-foreground mt-1">Use ${'url'} placeholder.</div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="usersummary" className="space-y-4">
          <Card className="mt-2">
            <CardHeader>
              <CardTitle>User Message Summary</CardTitle>
              <CardDescription>Resolve a user by email and view recent logs.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Input placeholder="user@example.com" value={summaryEmail} onChange={(e)=> setSummaryEmail(e.target.value)} className="w-80" />
                <Button onClick={()=> messagesSummaryMutation.mutate()} disabled={!summaryEmail || messagesSummaryMutation.isPending}>
                  {messagesSummaryMutation.isPending ? 'Loading...' : 'Check'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="diagnostics" className="space-y-4">
          <Card className="mt-2">
            <CardHeader>
              <CardTitle>Ibiki Diagnostics</CardTitle>
              <CardDescription>Run system checks and view results.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 mb-3">
                <Button onClick={() => diagnosticsQuery.refetch?.()} data-testid="button-run-diagnostics">
                  {diagnosticsQuery.isFetching ? 'Running…' : 'Run Diagnostics'}
                </Button>
                {diagnosticsQuery.data && (
                  <Button variant="outline" onClick={() => navigator.clipboard.writeText(JSON.stringify(diagnosticsQuery.data, null, 2))}>Copy JSON</Button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {(diagnosticsQuery.data?.checks || []).map((c: any, i: number) => (
                  <Card key={`diag-${i}`} className={c.status === 'pass' ? 'border-green-300' : 'border-red-300'}>
                    <CardHeader>
                      <CardTitle className="text-sm">{c.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-xs">Status: {c.status}</div>
                      <div className="text-xs">Duration: {c.durationMs}ms</div>
                      <pre className="mt-2 text-xs bg-muted/40 p-2 rounded overflow-auto max-h-[24vh]">{JSON.stringify(c.details, null, 2)}</pre>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="configuration" className="space-y-4">
          <Card className="border border-border/60">
            <CardHeader>
              <CardTitle>{t('admin.config.title')}</CardTitle>
              <CardDescription>
                {t('admin.config.subtitle')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSaveConfig} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="extremeApiKey">IbikiSMS API Key</Label>
                  <Input
                    id="extremeApiKey"
                    type="password"
                    placeholder="Enter IbikiSMS API key"
                    value={extremeApiKey}
                    onChange={(e) => setExtremeApiKey(e.target.value)}
                    data-testid="input-extreme-api-key"
                  />
                  <p className="text-xs text-muted-foreground">
                    This key is used to authenticate with IbikiSMS on behalf of all clients
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone">System Timezone</Label>
                  <Select value={timezone} onValueChange={setTimezone}>
                    <SelectTrigger id="timezone" data-testid="select-timezone">
                      <SelectValue placeholder="Select timezone" />
                    </SelectTrigger>
                    <SelectContent>
                      {usTimezones.map((tz) => (
                        <SelectItem key={tz.value} value={tz.value} textValue={tz.label}>
                          {tz.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    All timestamps in the system will be displayed in this timezone
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signupSeedExamples">Seed sample data for new signups</Label>
                  <div className="flex items-center gap-2">
                    <input
                      id="signupSeedExamples"
                      type="checkbox"
                      checked={signupSeedExamples}
                      onChange={(e) => setSignupSeedExamples(e.target.checked)}
                    />
                    <span className="text-xs text-muted-foreground">When enabled, new accounts receive example inbox/messages</span>
                  </div>
                </div>

                {profile?.user?.role === 'admin' && (
                  <div className="border-t pt-6 space-y-4">
                    <h3 className="text-lg font-semibold">Pricing Configuration</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="extremeCost">IbikiSMS Cost per SMS (USD)</Label>
                        <Input
                          id="extremeCost"
                          type="number"
                          step="0.0001"
                          placeholder="0.01"
                          value={extremeCost}
                          onChange={(e) => setExtremeCost(e.target.value)}
                          data-testid="input-extreme-cost"
                        />
                        <p className="text-xs text-muted-foreground">
                          What IbikiSMS charges you per message
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="clientRate">Client Rate per SMS (USD)</Label>
                        <Input
                          id="clientRate"
                          type="number"
                          step="0.0001"
                          placeholder="0.02"
                          value={clientRate}
                          onChange={(e) => setClientRate(e.target.value)}
                          data-testid="input-client-rate"
                        />
                        <p className="text-xs text-muted-foreground">
                          What you charge your clients per message
                        </p>
                      </div>
                    </div>

                    {profile?.user?.role === 'admin' && (
                      <div className="mt-6">
                        <h4 className="text-base font-semibold">Group Pricing Overview</h4>
                        <GroupPricingTable />
                      </div>
                    )}

                    <div className="mt-6 space-y-3">
                      <Label>Group Pricing (optional)</Label>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        <Select value={groupIdPricing || ''} onValueChange={(v) => setGroupIdPricing(v)}>
                          <SelectTrigger data-testid="select-pricing-group">
                            <SelectValue placeholder="Select Group ID" />
                          </SelectTrigger>
                          <SelectContent>
                          {(clients || []).map(c => c.groupId).filter(Boolean).filter((v, i, a) => a.indexOf(v) === i).map(g => (
                              <SelectItem key={String(g)} value={String(g)} textValue={String(g)}>{String(g)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Input type="number" step="0.0001" placeholder="Group Extreme Cost" value={groupExtremeCost}
                          onChange={(e) => setGroupExtremeCost(e.target.value)} data-testid="input-group-extreme" />
                        <Input type="number" step="0.0001" placeholder="Group Client Rate" value={groupClientRate}
                          onChange={(e) => setGroupClientRate(e.target.value)} data-testid="input-group-rate" />
                      </div>
                      <div className="text-xs text-muted-foreground">If no Group ID is selected, the default pricing above is used.</div>
                      <div className="flex items-center gap-2">
                        <Button type="button" variant="outline" disabled={!groupIdPricing} onClick={() => saveGroupPricingMutation.mutate()} data-testid="button-save-group-pricing">Save Group Pricing</Button>
                        {groupPricingQuery.data?.group && (groupPricingQuery.data.group.extremeCost || groupPricingQuery.data.group.clientRate) ? (
                          <Badge>Group configured</Badge>
                        ) : <Badge variant="secondary">Group not set</Badge>}
                      </div>
                    </div>

                    <div className="bg-muted/50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Profit Margin per SMS:</span>
                        <span className="text-lg font-bold text-primary" data-testid="text-profit-margin">
                          ${(parseFloat(clientRate || "0") - parseFloat(extremeCost || "0")).toFixed(4)} USD
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <Button type="submit" data-testid="button-save-config" disabled={saveConfigMutation.isPending}>
                    {saveConfigMutation.isPending ? "Saving..." : "Save Configuration"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    data-testid="button-test-connection"
                    onClick={() => testConnectionMutation.mutate()}
                    disabled={testConnectionMutation.isPending}
                  >
                    {testConnectionMutation.isPending ? "Testing..." : "Test Connection"}
                  </Button>
                  {connectionStatus !== 'unknown' && (
                    <Badge variant={connectionStatus === 'connected' ? 'default' : 'destructive'}>
                      {connectionStatus === 'connected' ? '✓ Connected' : '✗ Disconnected'}
                    </Badge>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>

          <Card className="border border-border/60">
            <CardHeader>
              <CardTitle>{t('admin.envDb.title')}</CardTitle>
              <CardDescription>Overview of critical configuration and database state</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Database Connection</span>
                    {dbStatusQuery.isLoading ? (
                      <Badge variant="secondary">Checking…</Badge>
                    ) : dbStatusQuery.data?.success ? (
                      <Badge>Connected</Badge>
                    ) : (
                      <Badge variant="destructive">Error</Badge>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Connected: {dbStatusQuery.data?.connection ? `${dbStatusQuery.data.connection.host}:${dbStatusQuery.data.connection.port}/${dbStatusQuery.data.connection.database}` : '—'}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Tables: {dbStatusQuery.data?.tables ? dbStatusQuery.data.tables.length : 0}
                  </div>
                  {dbStatusQuery.data?.tables && dbStatusQuery.data.tables.length > 0 && (
                    <pre className="text-xs bg-muted p-2 rounded overflow-x-auto">
                      {dbStatusQuery.data.tables.slice(0, 10).join('\n')}
                    </pre>
                  )}
                  <div className="flex items-center gap-2">
                    <Button onClick={() => runMigrationsMutation.mutate()} disabled={runMigrationsMutation.isPending}>
                      {runMigrationsMutation.isPending ? t('common.loading') : t('admin.envDb.runMigrations')}
                    </Button>
                    <Button variant="secondary" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/admin/db/status'] })}>{t('common.refresh')}</Button>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">IbikiSMS Key</span>
                    {(config?.config?.extreme_api_key) ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Timezone</span>
                    {(config?.config?.timezone) ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Client Rate per SMS</span>
                    {(config?.config?.client_rate_per_sms) ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">IbikiSMS Cost per SMS</span>
                    {(config?.config?.extreme_cost_per_sms) ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Note: JWT/Session secrets are stored in server environment and not displayed.
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">JWT Secret</span>
                      <div className="flex items-center gap-2">
                        {secretsStatusQuery.data?.configured?.jwt_secret ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                        {secretsStatusQuery.data?.envPresent?.JWT_SECRET ? <Badge>Env present</Badge> : <Badge variant="secondary">Env missing</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Session Secret</span>
                      <div className="flex items-center gap-2">
                        {secretsStatusQuery.data?.configured?.session_secret ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                        {secretsStatusQuery.data?.envPresent?.SESSION_SECRET ? <Badge>Env present</Badge> : <Badge variant="secondary">Env missing</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Webhook Secret</span>
                      <div className="flex items-center gap-2">
                        {secretsStatusQuery.data?.configured?.webhook_secret ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                        {secretsStatusQuery.data?.envPresent?.WEBHOOK_SECRET ? <Badge>Env present</Badge> : <Badge variant="secondary">Env missing</Badge>}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Resend API Key</span>
                      <div className="flex items-center gap-2">
                        {secretsStatusQuery.data?.configured?.resend_api_key ? <Badge>Configured</Badge> : <Badge variant="secondary">Not set</Badge>}
                        {secretsStatusQuery.data?.envPresent?.RESEND_API_KEY ? <Badge>Env present</Badge> : <Badge variant="secondary">Env missing</Badge>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="outline" onClick={() => rotateSecretMutation.mutate('jwt_secret')} disabled={rotateSecretMutation.isPending}>Rotate JWT</Button>
                    <Button variant="outline" onClick={() => rotateSecretMutation.mutate('session_secret')} disabled={rotateSecretMutation.isPending}>Rotate Session</Button>
                    <Button variant="outline" onClick={() => rotateSecretMutation.mutate('webhook_secret')} disabled={rotateSecretMutation.isPending}>Rotate Webhook</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhook" className="space-y-4">
          {/* Docs content removed per request; leaving only diagnostics */}

          <Card className="border border-border/60">
            <CardHeader>
              <CardTitle>Webhook Diagnostics</CardTitle>
              <CardDescription>Simulate inbound webhook and verify routing to Ibiki inbox</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="p-3 mb-4 rounded border bg-muted/40">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold">ExtremeSMS Webhook URL</div>
                    <div className="text-xs text-muted-foreground">Use this URL in ExtremeSMS so Ibiki can receive replies.</div>
                    <div className="mt-2 font-mono text-xs break-all" data-testid="text-suggested-webhook">
                      {secretsStatusQuery.data?.suggestedWebhook || 'https://ibiki.run.place/api/webhook/extreme-sms'}
                    </div>
                    <div className="mt-1 text-xs">
                      Configured: <span className="font-mono" data-testid="text-configured-webhook">{secretsStatusQuery.data?.configuredWebhook || '—'}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" onClick={() => navigator.clipboard.writeText(String(secretsStatusQuery.data?.suggestedWebhook || 'https://ibiki.run.place/api/webhook/extreme-sms'))} data-testid="button-copy-webhook">Copy</Button>
                    <Button onClick={() => setWebhookUrlMutation.mutate(String(secretsStatusQuery.data?.suggestedWebhook || 'https://ibiki.run.place/api/webhook/extreme-sms'))} data-testid="button-set-webhook">Set Webhook URL</Button>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label>From (sender phone)</Label>
                  <Input value={webhookFrom} onChange={(e) => setWebhookFrom(e.target.value)} placeholder="+1-555-0000" />
                </div>
                <div>
                  <Label>Business</Label>
                  <Input value={webhookBusiness} onChange={(e) => setWebhookBusiness(e.target.value)} placeholder="Client business name" />
                </div>
                <div>
                  <Label>Message</Label>
                  <Input value={webhookMessage} onChange={(e) => setWebhookMessage(e.target.value)} placeholder="Hello from test" />
                </div>
                <div>
                  <Label>Message ID (optional)</Label>
                  <Input value={webhookMessageId} onChange={(e) => setWebhookMessageId(e.target.value)} placeholder="Provide custom messageId" />
                </div>
              </div>
              <div className="flex items-center gap-2 mt-4">
                <Button onClick={() => webhookTestMutation.mutate()} disabled={webhookTestMutation.isPending}>
                  {webhookTestMutation.isPending ? t('common.loading') : 'Send Test Webhook'}
                </Button>
                <Button variant="secondary" onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/admin/webhook/status'] })}>Refresh Status</Button>
                <Button variant="outline" onClick={() => inboxRetrieveMutation.mutate()} disabled={inboxRetrieveMutation.isPending}>
                  {inboxRetrieveMutation.isPending ? 'Retrieving…' : 'Retrieve Inbox Now'}
                </Button>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 border rounded">
                  <h4 className="font-semibold mb-2">Last Webhook Event</h4>
                  <p className="text-xs text-muted-foreground">At: {webhookStatusQuery.data?.lastEventAt || '—'}</p>
                  <p className="text-xs">Message ID: {webhookStatusQuery.data?.lastEvent?.messageId || '—'}</p>
                  <p className="text-xs">Modem: {webhookStatusQuery.data?.lastEvent?.usedmodem || '—'} · Port: {webhookStatusQuery.data?.lastEvent?.port || '—'}</p>
                  <pre className="text-xs bg-muted p-2 rounded overflow-x-auto">{JSON.stringify(webhookStatusQuery.data?.lastEvent || null, null, 2)}</pre>
                  <p className="text-xs mt-2">Routed User: {webhookStatusQuery.data?.lastRoutedUser || '—'}</p>
                  <div className="mt-3 p-2 rounded bg-muted/40">
                    <p className="text-xs">Last Inbox Pull: {String((webhookStatusQuery.data as any)?.lastInboxAt || '—')}</p>
                    <p className="text-xs">Processed Count: {String((webhookStatusQuery.data as any)?.lastInboxCount ?? '—')}</p>
                  </div>
                </div>
                <div className="p-3 border rounded">
                  <h4 className="font-semibold mb-2">Flow Check</h4>
                  <Label>Business</Label>
                  <Input value={flowBusiness} onChange={(e) => setFlowBusiness(e.target.value)} placeholder="Client business name" />
                  <Button className="mt-2" onClick={() => flowCheckMutation.mutate()} disabled={flowCheckMutation.isPending}>
                    {flowCheckMutation.isPending ? t('common.loading') : 'Check Routing'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing" className="space-y-4">
          <ApiTestUtility />
        </TabsContent>

        <TabsContent value="groupreport" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Group Message Status (Today)</CardTitle>
              <CardDescription>Sent and first-time received counts per user</CardDescription>
            </CardHeader>
            <CardContent>
              {profile?.user?.role === 'admin' && (
                <div className="flex items-center gap-2 mb-3">
                  <Input placeholder="Group ID" value={groupIdPricing} onChange={e => setGroupIdPricing(e.target.value)} className="w-64" />
                  <Input type="date" value={groupReportDate} onChange={e => setGroupReportDate(e.target.value)} />
                  <Button variant="secondary" onClick={() => setGroupReportTrigger((n) => n + 1)}>Load</Button>
                  {groupIdPricing && (
                    <Button onClick={() => exportGroupCsv({ groupId: groupIdPricing, date: groupReportDate || undefined })}>Export CSV</Button>
                  )}
                </div>
              )}
              {profile?.user?.role === 'supervisor' && (
                <div className="flex items-center gap-2 mb-3">
                  <Input type="date" value={groupReportDate} onChange={e => setGroupReportDate(e.target.value)} />
                  <Button variant="secondary" onClick={() => setGroupReportTrigger((n) => n + 1)}>Load</Button>
                  <Button onClick={() => exportGroupCsv({ date: groupReportDate || undefined })}>Export CSV</Button>
                </div>
              )}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead className="text-right">Sent Today</TableHead>
                    <TableHead className="text-right">Received (First-Time)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(groupStatsQuery.data?.results || []).map((row) => (
                    <TableRow key={row.user_id}>
                      <TableCell>{row.user_name}</TableCell>
                      <TableCell>{row.email}</TableCell>
                      <TableCell className="text-right">{row.sent_today}</TableCell>
                      <TableCell className="text-right">{row.received_today}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {profile?.user?.role !== 'admin' ? (
          <TabsContent value="actionlogs" className="space-y-4">
            <SupervisorLogsTable />
          </TabsContent>
        ) : null}

        <TabsContent value="actionlogs" className="space-y-4">
          <ActionLogsViewer />
        </TabsContent>

        <TabsContent value="messages" className="space-y-4">
          {profile?.user?.role === 'admin' ? <MessageActivityViewer /> : <MessageActivityViewer mode="supervisor" />}
        </TabsContent>

        <TabsContent value="createuser" className="space-y-4">
          {profile?.user?.role === 'admin' ? <AdminCreateUser /> : <SupervisorCreateUser />}
        </TabsContent>



        <TabsContent value="monitoring" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent API Activity</CardTitle>
              <CardDescription>Monitor real-time API requests and responses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivity?.logs && recentActivity.logs.length > 0 ? (
                  recentActivity.logs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-3 rounded-lg border border-border" data-testid={`activity-${log.id}`}>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{log.endpoint}</p>
                        <p className="text-xs text-muted-foreground">
                          Client: {log.clientName} • {new Date(log.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <Badge 
                        className={
                          log.status === 'delivered' || log.status === 'sent' || log.status === 'queued'
                            ? "bg-green-500/10 text-green-600 dark:text-green-400"
                            : "bg-red-500/10 text-red-600 dark:text-red-400"
                        }
                      >
                        {log.status}
                      </Badge>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <p className="text-sm">No recent API activity</p>
                    <p className="text-xs mt-1">Activity will appear here when clients use the API</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}
function SupervisorLogsTable() {
  const { t } = useLanguage();
  const { data } = useQuery<{ success: boolean; logs: Array<{ id: string; actorUserId: string; actorEmail?: string | null; actorName?: string | null; actorRole: string; targetUserId: string | null; targetEmail?: string | null; targetName?: string | null; action: string; details: string | null; createdAt: string }> }>({
    queryKey: ['/api/supervisor/logs'],
    queryFn: async () => {
      const token = localStorage.getItem('token');
      const r = await fetch('/api/supervisor/logs', { headers: token ? { 'Authorization': `Bearer ${token}` } : {} });
      if (!r.ok) {
        const text = await r.text();
        throw new Error(text || 'Failed to fetch logs');
      }
      return r.json();
    }
  });
  const logs = data?.logs || [];
  const [lookup, setLookup] = useState("");
  const [lookupResult, setLookupResult] = useState<string>("");
  const resolveLookup = async () => {
    try {
      const token = localStorage.getItem('token');
      const resp = await fetch(`/api/admin/users/resolve?id=${encodeURIComponent(lookup)}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
      const json = await resp.json();
      if (json?.success) setLookupResult(json.user?.name || json.user?.email || lookup);
      else setLookupResult('Not found');
    } catch {
      setLookupResult('Not found');
    }
  };
  const exportTxt = () => {
    const lines = logs.map(l => `${l.createdAt} | actor=${l.actorUserId}(${l.actorRole}) | action=${l.action} | target=${l.targetUserId || ''} | details=${l.details || ''}`).join('\n');
    const blob = new Blob([lines], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'group-logs.txt'; a.click(); URL.revokeObjectURL(url);
  };
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Input placeholder="Translate ID" className="w-64" onChange={(e) => setLookup(e.target.value)} />
          <Button size="sm" onClick={resolveLookup} disabled={!lookup}>{t('common.translate') || 'Translate'}</Button>
          {lookupResult && (<span className="text-xs text-muted-foreground">{lookupResult}</span>)}
        </div>
        <Button size="sm" variant="outline" onClick={exportTxt}>{t('logs.export') || 'Export'}</Button>
      </div>
      <div className="max-h-[65vh] overflow-y-auto rounded border">
        <Table className="min-w-full">
        <TableHeader>
          <TableRow>
            <TableHead>Time</TableHead>
            <TableHead>Actor</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Action</TableHead>
            <TableHead>Target User</TableHead>
            <TableHead>Details</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {logs.map(l => (
            <TableRow key={l.id}>
              <TableCell>{new Date(l.createdAt).toLocaleString()}</TableCell>
              <TableCell className="truncate max-w-[220px] text-xs">{(l as any).actorDisplay || l.actorName || l.actorEmail || l.actorUserId}</TableCell>
              <TableCell>{l.actorRole}</TableCell>
              <TableCell className="font-mono text-xs">{l.action}</TableCell>
              <TableCell className="truncate max-w-[220px] text-xs">{(l as any).targetDisplay || l.targetName || l.targetEmail || l.targetUserId || '-'}</TableCell>
              <TableCell className="font-mono text-xs break-words">{l.details || '-'}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      </div>
    </div>
  );
}
  
