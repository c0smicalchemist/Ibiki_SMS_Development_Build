import AdminDashboard from '../../pages/AdminDashboard';

export default function AdminDashboardExample() {
  return <AdminDashboard />;
}
