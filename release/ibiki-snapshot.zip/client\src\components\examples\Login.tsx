import Login from '../../pages/Login';

export default function LoginExample() {
  return <Login />;
}
